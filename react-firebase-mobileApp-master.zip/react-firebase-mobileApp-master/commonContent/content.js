const content ={
    addTextContent : "Input text can be in your own language or your language in english words.You can add your own translation or click get translation and look at Translated Text area to get our suggesstion",
    addTextExample : " From : Tamil, To : English ,  Input : 'Vanakkam'  Output : 'Hello' ",
    getTranslate : "Translated Text",
}

export default content