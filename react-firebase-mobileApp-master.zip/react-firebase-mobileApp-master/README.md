# Langugage Translator

This is a collabrative learning improvement Mobile app based on react-native. 

Languages Used :

1. Java Script
2. JSX
3. Html, CSS 
4. WebPack

Condition : Under Work in progress.
