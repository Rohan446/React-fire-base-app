const TextApi = {
    url: "https://translate.yandex.net/api/v1.5/tr.json/translate",
    key:"trnsl.1.1.20200116T154040Z.c8fd8b8441c4b55a.5b2ba0ddb6e18792d3a5c83ded30055c79c0a363",
}
export default TextApi;